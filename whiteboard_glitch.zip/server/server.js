import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import fs from 'fs';
import path from 'path';
const __dirname = path.resolve();
const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*' } });
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'strokes.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({ strokes: [], clearedAt: null }));
function readDB(){return JSON.parse(fs.readFileSync(DATA_FILE));}
function writeDB(db){fs.writeFileSync(DATA_FILE, JSON.stringify(db));}
let db = readDB();
app.use('/static', express.static(path.join(__dirname, 'client')));
app.get('/', (req,res)=> res.sendFile(path.join(__dirname, 'client', 'index.html')));
io.on('connection', (socket)=>{
  socket.emit('init', { strokes: db.strokes, clearedAt: db.clearedAt });
  socket.on('stroke', (stroke)=>{ db.strokes.push(stroke); writeDB(db); io.emit('stroke', stroke); });
  socket.on('clear', ()=>{ db = { strokes: [], clearedAt: Date.now() }; writeDB(db); io.emit('cleared'); });
});
server.listen(3000, ()=> console.log('Server on http://localhost:3000'));
